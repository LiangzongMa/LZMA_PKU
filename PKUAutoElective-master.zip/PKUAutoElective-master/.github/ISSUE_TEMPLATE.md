### Check List

- [ ] 我已经阅读了 [Readme](https://github.com/zhongxinghong/PKUAutoElective/blob/master/README.md), [Migration Guide](https://github.com/zhongxinghong/PKUAutoElective/blob/master/MIGRATION_GUIDE.md), [Realease History](https://github.com/zhongxinghong/PKUAutoElective/blob/master/HISTORY.md) ，但是并没有找到有用的信息
- [ ] 我已经搜索了已有的 [Issues](https://github.com/zhongxinghong/PKUAutoElective/issues) ，但是没有找到相同的问题

### Version / Environment

System infomation: [ ] \( Windows10 64bit, MacOS 10.13.6, Ubuntu 18.04.3 amd64, ... )
Python version: [ ] \( run `python3 --version` )
AutoElective version: [ ] \( run `python3 main.py --version` )

### Config

除了学号/密码外的其他配置

### Issue Description

#### What

遇到的问题

#### Console Log

必要的终端输出信息

#### Reproduce

如有必要，提供复现的步骤

<!-- Reference to https://github.com/onevcat/Kingfisher/blob/master/.github/ISSUE_TEMPLATE.md -->

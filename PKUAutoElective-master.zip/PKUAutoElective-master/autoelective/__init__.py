#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# filename: __init__.py
# modified: 2019-09-13

__version__ = "3.0.3"
__date__    = "2020.02.17"
__author__  = "Rabbit"
